package cs5004.animator.model;

import java.io.FileNotFoundException;
import java.util.Scanner;
import cs5004.animator.controller.Controller;
import cs5004.animator.view.EmptyView;
import cs5004.animator.view.View;


/**
 * A simple animator class that allows us to create animations using different files. It calls upon
 * the Animation Reader, Builder and the Model to create animations.
 */
public class SimpleAnimator {

  /**
   * This class initialize the MVC and give the controller the ability to manage user input.
   *
   * @param args user's input from terminal.
   * @throws FileNotFoundException when requested file that doesn't exists.
   */
  public static void main(String[] args) throws FileNotFoundException {
    Scanner scan = new Scanner(System.in);
    String input = scan.nextLine();
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();

  }


}