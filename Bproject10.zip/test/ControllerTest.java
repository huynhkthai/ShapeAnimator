import org.junit.Test;

import java.io.FileNotFoundException;

import cs5004.animator.controller.Controller;
import cs5004.animator.model.AnimationBuilder;
import cs5004.animator.model.AnimationBuilderImpl;
import cs5004.animator.view.EmptyView;
import cs5004.animator.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This represents the JUnit test class for the Controller. It will be used to verify that the user
 * inputs were correctly. By calling goAnimation before any equalsAssertion, we verify that the
 * controller properly read the data.
 */
public class ControllerTest {

  //hanoi.txt speed 100
  //big-bang-big-crunch speed 15
  //buildings speed


  @Test
  public void testViewTypeIsCorrect() throws FileNotFoundException {
    String input = "-in hanoi.txt -view visual";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertTrue(controller.getView().getViewType().equalsIgnoreCase("visual"));
  }

  @Test
  public void testViewTypeIsCorrectText() throws FileNotFoundException {
    String input = "-in hanoi.txt -view text";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertTrue(controller.getView().getViewType().equalsIgnoreCase("text"));
  }

  @Test
  public void testViewTypeIsCorrectSVG() throws FileNotFoundException {
    String input = "-in hanoi.txt -view SVG";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertEquals("SVG", controller.getView().getViewType());
  }

  @Test
  public void testViewTypeIsNo()throws FileNotFoundException {
    String input = "-in hanoi.txt -view SVG";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertEquals("SVG", controller.getView().getViewType());
  }

  //try entering a visual that does not exist
  //-in buildings.txt -view svg -out testFile
  //-in buildings.txt -view svg -out testFile speed 15


  @Test(expected = IllegalArgumentException.class)
  public void testInvalidViewType() throws FileNotFoundException {
    String input = "-in hanoi.txt -view graphic -out";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);

  }

  //Expecting an exception when a filename is not given to an outfile
  @Test(expected = FileNotFoundException.class)
  public void testRequestOutWithoutFileName() throws FileNotFoundException {
    String input = "-in hanoi.txt -view text -out";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
  }

  //Expecting an exception to be thrown for having -out before -in.
  @Test(expected = FileNotFoundException.class)
  public void testOutBeforeIn() throws FileNotFoundException {
    String input = "-out hanoi.txt -view text -in";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testNegativeSpeed() throws FileNotFoundException {
    String input = "-speed -3 -in hanoi.txt -view text";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
  }

  @Test
  public void testGettingSpeed() throws FileNotFoundException {
    String input = "-in hanoi.txt -view playback -speed 25";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertEquals(25, controller.getSpeed(), 0.0001);
  }
}
