import org.junit.Test;

import java.io.FileNotFoundException;

import javax.swing.*;

import cs5004.animator.controller.Controller;
import cs5004.animator.model.AnimationBuilder;
import cs5004.animator.model.AnimationBuilderImpl;
import cs5004.animator.model.Shape;
import cs5004.animator.view.EmptyView;
import cs5004.animator.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This represents the JUnit test class for the Controller. It will be used to verify that the user
 * inputs were correctly. By calling goAnimation before any equalsAssertion, we verify that the
 * controller properly read the data.
 */
public class ControllerTest {

  @Test
  public void testViewTypeIsCorrect() throws FileNotFoundException {
    String input = "-in hanoi.txt -view visual";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertTrue(controller.getView().getViewType().equalsIgnoreCase("visual"));
  }

  @Test
  public void testViewTypeIsCorrectText() throws FileNotFoundException {
    String input = "-in hanoi.txt -view text";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertTrue(controller.getView().getViewType().equalsIgnoreCase("text"));
  }

  @Test
  public void testViewTypeIsCorrectSVG() throws FileNotFoundException {
    String input = "-in hanoi.txt -view SVG";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertEquals("SVG", controller.getView().getViewType());
  }

  @Test
  public void testViewTypeIsNo()throws FileNotFoundException {
    String input = "-in hanoi.txt -view SVG";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertEquals("SVG", controller.getView().getViewType());
  }


  @Test
  public void testInvalidViewType() throws FileNotFoundException {
    String input = "-in hanoi.txt -view graphic -out";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
  }

  //Expecting an exception when a filename is not given to an outfile
  @Test (expected = IllegalArgumentException.class)
  public void testRequestOutWithoutFileName() throws FileNotFoundException {
    String input = "-in hanoi.txt -view text -out";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
  }

  //Could not figure out syntax to check expected error message from JOption
  //  //Expecting an exception to be thrown for having -out before -in.
  //  @Test(expected = JOptionPane.ERROR_MESSAGE.class)
  //  public void testOutBeforeIn() throws FileNotFoundException {
  //      String input = "-out hanoi.txt -view text -in";
  //      AnimationBuilder model = new AnimationBuilderImpl();
  //      View view = new EmptyView();
  //      Controller controller = new Controller(model, view, input);
  //
  //      assertEquals(0, controller.ERROR_MESSAGE);
  //  }


  @Test(expected = IllegalArgumentException.class)
  public void testNegativeSpeed() throws FileNotFoundException {
    String input = "-speed -3 -in hanoi.txt -view text";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
  }

  //test that the speed is being set properly for playback view
  @Test
  public void testGettingSpeedPlayback() throws FileNotFoundException {
    String input = "-in hanoi.txt -view playback -speed 25";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertEquals(25, controller.getSpeed());
  }

  //testing that speed is set correctly for svg view
  @Test
  public void testGettingSpeedSVG() throws FileNotFoundException {
    String input = "-in hanoi.txt -view svg -speed 25";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertEquals(25, controller.getSpeed());
  }


  //This will test that the controller successfully managed to go into the model class.

  @Test
  public void testSizingOfCanvas() throws FileNotFoundException {
    String input = "-in hanoi.txt -view svg -speed 25";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    Shape canvas = controller.getCanvas();
    assertEquals(10, canvas.getX());
    assertEquals(0,canvas.getY());
    assertEquals(640,canvas.getParameter1());
    assertEquals(225,canvas.getParameter2());
  }

  //This will test that a shape exists in the current animation.
  @Test
  public void testShapeExistenceInAnimationSVG() throws FileNotFoundException {
    String input = "-in buildings.txt -view svg -speed 25";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertTrue(controller.getModel().shapeExist("eclipse"));
    //star class not included in model, but was successfully added to the model
    assertTrue(controller.getModel().shapeExist("star1"));
  }

  @Test
  public void testShapeExistenceInAnimationPlayback() throws FileNotFoundException {
    String input = "-in buildings.txt -view playback -speed 25";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertTrue(controller.getModel().shapeExist("eclipse"));
    //star class not included in model, but was successfully added to the model
    assertTrue(controller.getModel().shapeExist("star1"));
  }

  @Test
  public void testShapeExistenceInAnimationVisual() throws FileNotFoundException {
    String input = "-in buildings.txt -view visual -speed 25";
    AnimationBuilder model = new AnimationBuilderImpl();
    View view = new EmptyView();
    Controller controller = new Controller(model, view, input);
    controller.goAnimation();
    assertTrue(controller.getModel().shapeExist("eclipse"));
    //star class not included in model, but was successfully added to the model
    assertTrue(controller.getModel().shapeExist("star1"));
  }

}
