import org.junit.Test;

import cs5004.animator.model.AnimatorImpl;
import cs5004.animator.model.Circle;
import cs5004.animator.model.Oval;
import cs5004.animator.model.Rectangle;
import cs5004.animator.model.Shape;
import cs5004.animator.model.ShapeName;

import static org.junit.Assert.assertEquals;

/**
 * This is a test class that test the functionality of Model.AnimatorImpl.
 */
public class AnimatorImplTest {

  @Test
  public void testAnimation() {
    AnimatorImpl test = new AnimatorImpl();

    // Testing empty registers.
    assertEquals("Shapes: " + "\n" + "\n", test.getAnimation()); // Empty registers.

    // Test creating a Model.Rectangle.
    Rectangle check = test.createRectangle("R", 3, 3, 4, 6, 15,
            25, 0, 0, 1, ShapeName.Rectangle);

    //Testing register after shape is created.
    assertEquals("Shapes: \n" + "Name: R" + "\n" + "Type: Model.Rectangle" + "\n"
            + "Min Corner: (3.0,3.0), Width: 4.0, Height: 6.0, Color: (0.0,0.0,1.0)" + "\n"
            + "Appears at t=15.0\n" + "Disappears at t=25.0\n" + "\n", test.getAnimation());

    // Testing mutation, changed color.
    test.changeColor(check, 1, 1, 1, 17, 19);
    assertEquals("Shapes: \n" + "Name: R" + "\n" + "Type: Model.Rectangle" + "\n"
                    + "Min Corner: (3.0,3.0), Width: 4.0, Height: 6.0, Color: (0.0,0.0,1.0)" + "\n"
                    + "Appears at t=15.0\n" + "Disappears at t=25.0\n" + "\n"
                    + "Model.Shape R changes color from (0.0,0.0,1.0)"
                    + " to (1.0,1.0,1.0) from t=17.0 to t=19.0\n",
            test.getAnimation());

    // Testing creating an Model.Oval.
    Oval oval = test.createOval("O", 2, 2, 3, 5, 5,
            15, 1, 1, 1, ShapeName.Ellipse);
    assertEquals("Shapes: \n" + "Name: R" + "\n" + "Type: Model.Rectangle" + "\n"
                    + "Min Corner: (3.0,3.0), Width: 4.0, Height: 6.0, Color: (0.0,0.0,1.0)" + "\n"
                    + "Appears at t=15.0\n" + "Disappears at t=25.0\n"
                    + "Name: O" + "\n" + "Type: Model.Oval\n"
                    + "Center: (2.0,2.0), Width: 6.0, Height: 10.0,"
                    + " Color: (1.0,1.0,1.0)" + "\n"
                    + "Appears at t=5.0\n" + "Disappears at t=15.0\n" + "\n"
                    + "Model.Shape R changes color from (0.0,0.0,1.0)"
                    + " to (1.0,1.0,1.0) from t=17.0 to t=19.0\n",
            test.getAnimation());

    //Test mutation on Model.Oval.
    test.scaleOval(oval, 3, 7, 10);
    assertEquals("Shapes: \n" + "Name: R" + "\n" + "Type: Model.Rectangle" + "\n"
                    + "Min Corner: (3.0,3.0), Width: 4.0, Height: 6.0, Color: (0.0,0.0,1.0)" + "\n"
                    + "Appears at t=15.0\n" + "Disappears at t=25.0\n"
                    + "Name: O" + "\n" + "Type: Model.Oval\n" + "Center: (2.0,2.0), Width: 6.0, "
                    + "Height: 10.0,"
                    + " Color: (1.0,1.0,1.0)" + "\n"
                    + "Appears at t=5.0\n" + "Disappears at t=15.0\n" + "\n"
                    + "Model.Shape R changes color from (0.0,0.0,1.0) to (1.0,1.0,1.0) "
                    + "from t=17.0 to t=19.0\n"
                    + "Model.Shape O scales from Vertical Radius: 5.0 Horizontal Radius: 3.0 to "
                    + "Vertical Radius: 15.0 "
                    + "Horizontal Radius: 9.0 from t=5.0 to t=15.0" + "\n",
            test.getAnimation());

    //Test same mutation + twice mutation on same shape
    test.scaleOval(oval, 3, 7, 10);
    assertEquals("Shapes: \n" + "Name: R" + "\n" + "Type: Model.Rectangle" + "\n"
                    + "Min Corner: (3.0,3.0), Width: 4.0, Height: 6.0, Color: (0.0,0.0,1.0)" + "\n"
                    + "Appears at t=15.0\n" + "Disappears at t=25.0\n"
                    + "Name: O" + "\n" + "Type: Model.Oval\n" + "Center: (2.0,2.0), Width: 6.0, "
                    + "Height: 10.0,"
                    + " Color: (1.0,1.0,1.0)" + "\n"
                    + "Appears at t=5.0\n" + "Disappears at t=15.0\n" + "\n"
                    + "Model.Shape R changes color from (0.0,0.0,1.0) to (1.0,1.0,1.0) "
                    + "from t=17.0 to t=19.0\n"
                    + "Model.Shape O scales from Vertical Radius: 5.0 Horizontal Radius: 3.0 to "
                    + "Vertical Radius: 15.0 Horizontal Radius: 9.0 from t=5.0 to t=15.0" + "\n"
                    + "Model.Shape O scales from Vertical Radius: 15.0 Horizontal Radius: 9.0 to "
                    + "Vertical Radius: 45.0 Horizontal Radius: 27.0 from t=5.0 to t=15.0" + "\n",
            test.getAnimation());

    // create Model.Circle and move it in a new animation
    AnimatorImpl testAnimation = new AnimatorImpl();
    Circle newCircle = testAnimation.createCircle("C", 3, 4, 5, 4,
            8, 1, 0, 1, ShapeName.Circle);
    // Moving a circle shape
    testAnimation.moveShape(newCircle, 7, 10, 4, 8);
    assertEquals("Shapes: " + "\n" + "Name: C" + "\n"
                    + "Type: Model.Circle" + "\n"
                    + "Center: (3.0,4.0), Diameter: 10.0, Radius: 5.0, Color : (1.0,0.0,1.0)\n"
                    + "Appears at t=4.0\n" + "Disappears at t=8.0\n" + "\n"
                    + "Model.Shape C moves from (3.0, 4.0) to (7.0,10.0) from t=4.0 to t=8.0\n",
            testAnimation.getAnimation());
  }

  @Test(expected = IllegalArgumentException.class)
  public void shapeWithSameName() {
    AnimatorImpl test = new AnimatorImpl();
    Shape check = test.createRectangle("R", 3, 3, 4, 6, 15,
            25, 0, 0, 1, ShapeName.Rectangle);

    // Same type Same Name
    Shape check2 = test.createRectangle("R", 3, 3, 4, 6, 15,
            25, 0, 0, 1, ShapeName.Rectangle);

    // Different Type Same Name
    Shape check3 = test.createOval("R", 3, 3, 4, 6,
            15, 25, 0, 0, 1, ShapeName.Ellipse);
  }

  @Test(expected = IllegalArgumentException.class)
  public void shapeInvalidConstruction() {
    AnimatorImpl test = new AnimatorImpl();
    Rectangle check = test.createRectangle("R", 3, 3, 4, 6, 75,
            25, 257, 0, 1, ShapeName.Rectangle);
    Circle testC = test.createCircle("C", -13, 3, 4, 6, 75,
            25, 256, 0, ShapeName.Circle);
    Oval check3 = test.createOval("R", 3, 3, 0, -1,
            75, 25, 257, 0, 1, ShapeName.Ellipse);
  }
}