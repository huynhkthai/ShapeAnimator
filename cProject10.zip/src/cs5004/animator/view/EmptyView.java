package cs5004.animator.view;

/**
 * This represents an EmptyView class. This view is simply used to initialize the view.
 */
public class EmptyView implements View {
  View view;

  public EmptyView() {
    view = null;
  }

  @Override
  public void render() {
    System.out.print("This is an empty View");
  }

  @Override
  public String getViewType() {
    return "Empty";
  }

}
